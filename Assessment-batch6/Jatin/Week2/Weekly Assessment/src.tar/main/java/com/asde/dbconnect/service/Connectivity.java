package com.asde.dbconnect.service;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connectivity {
    private static Connection connection = null;

    public static Connection getMySqlConnecion() throws Exception {
        if(connection==null){
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/vaccination","root","admin"); 
        }
        return connection;
    }
    
}
