package com.asde.file;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.asde.dbconnect.entities.VaccineSlot;
import com.asde.dbconnect.service.Connectivity;

public class FileReadingServiceImpl implements IFileReadingService {


	@Override
	public Integer getTotalSlotsForLocation(String location, String vaccineType) {
        Integer countOfVaccines=0;
        String sql="Select efficacy from vaccinecentredata where location =? and vaccinetype =?";
        Connection connection=null;
        try{
            connection=Connectivity.getMySqlConnecion();
        PreparedStatement ps=connection.prepareStatement(sql);
        ps.setString(1, location);
        ps.setString(2,vaccineType);

        ResultSet rs=ps.executeQuery();
        
        while(rs.next())
        {   countOfVaccines+=rs.getInt(1);
        }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return countOfVaccines;
	}

	@Override
	public List<VaccineSlot> readVaccinCentreData(String filename) {
        // TODO Auto-generated method stub
         List<VaccineSlot> slots = new ArrayList<VaccineSlot>();
        String sql="Select * from vaccinecentredata ";
        Connection connection=null;
        try{
            connection=Connectivity.getMySqlConnecion();
        PreparedStatement ps=connection.prepareStatement(sql);

        ResultSet rs=ps.executeQuery();
        while(rs.next())
        {   VaccineSlot vaccineslot=new VaccineSlot();
            vaccineslot.setSlot_id(rs.getInt(4));
            vaccineslot.setVaccine_id(rs.getString(1));
            vaccineslot.setLocation_name(rs.getString(2));
            vaccineslot.setIs_available(rs.getBoolean(3));
            
            slots.add(vaccineslot);   
        }
    }catch(Exception e){
        e.printStackTrace();
    }
        return slots;
	}

}
