package com.asde.dbconnect.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.asde.dbconnect.entities.VaccineSlot;
import com.asde.file.IFileReadingService;

public class SlotService implements ISlotService {

    private IFileReadingService frs;
    private String fileName;

    public SlotService(IFileReadingService frs, String fileName) {
        this.frs = frs;
        this.fileName = fileName;
    }

    /**
     * Get all available slots that are present in the file as a list of objects 
     * containing the location for each slot as well
     */
    @Override
    public List<VaccineSlot> getAllAvailableSlots() {
        List<VaccineSlot> slots = new ArrayList<VaccineSlot>();
        String sql="Select * from vaccine where is_available=True";
        Connection connection=null;
        try{
            connection=Connectivity.getMySqlConnecion();
        PreparedStatement ps=connection.prepareStatement(sql);

        ResultSet rs=ps.executeQuery();
        while(rs.next())
        {   VaccineSlot vaccineslot=new VaccineSlot();
            vaccineslot.setSlot_id(rs.getInt(4));
            vaccineslot.setVaccine_id(rs.getString(1));
            vaccineslot.setLocation_name(rs.getString(2));
            vaccineslot.setIs_available(rs.getBoolean(3));
            
            slots.add(vaccineslot);   
        }
    }catch(Exception e){
        e.printStackTrace();
    }
        return slots;
    }
    /**
     * Get the no of slots from the database for a specific vaccine and location
     * 
     * For example: gurgaon and covaxin
     */
     @Override
    public Integer getVaccineSlotsForLocationAndVaccine(String location, String vaccine_name) {
        // TODO Auto-generated method stub
        Integer countOfVaccines=0;
        String sql="Select efficacy from vaccinedata where location =? and vaccine =?";
        Connection connection=null;
        try{
        connection=Connectivity.getMySqlConnecion();
        PreparedStatement ps=connection.prepareStatement(sql);
        ps.setString(1, location);
        ps.setString(2,vaccine_name);

        ResultSet rs=ps.executeQuery();
        
        while(rs.next())
        {   countOfVaccines+=rs.getInt(1);
        }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return countOfVaccines;
    }

    /**
     * Get the list of all slots that are available for a particular location
     * 
     * For example: gurgaon
     */
    @Override
    public List<VaccineSlot> getVaccineSlotsForLocation(String location) {
    	List<VaccineSlot> slots = new ArrayList<VaccineSlot>();
        String sql="Select * from vaccine where location =? ";
        Connection connection=null;
        try{
            connection=Connectivity.getMySqlConnecion();
            PreparedStatement ps=connection.prepareStatement(sql);
        ps.setString(1, location);

        ResultSet rs=ps.executeQuery();
        while(rs.next())
        {   VaccineSlot vaccineslot=new VaccineSlot();
            vaccineslot.setSlot_id(rs.getInt(4));
            vaccineslot.setVaccine_id(rs.getString(1));
            vaccineslot.setLocation_name(rs.getString(2));
            vaccineslot.setIs_available(rs.getBoolean(3));
            
            slots.add(vaccineslot);   
        }
        
        }catch(Exception e){
            e.printStackTrace();
        }
        return slots; 
    }
    
}
