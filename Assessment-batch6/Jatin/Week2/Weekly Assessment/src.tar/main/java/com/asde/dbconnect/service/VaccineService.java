package com.asde.dbconnect.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.asde.dbconnect.entities.Vaccine;
import com.asde.file.IFileReadingService;

public class VaccineService implements IVaccineService {

	private IFileReadingService frs;
    private String fileName;

	public VaccineService(IFileReadingService frs, String fileName) {
		this.frs = frs;
        this.fileName = fileName;
	}

	public List<Vaccine> listAllVaccines() {
		 List<Vaccine> slots = new ArrayList<Vaccine>();
        String sql="Select * from vaccinecentredata";
                Connection connection=null;
        try{
            connection=Connectivity.getMySqlConnecion();
        PreparedStatement ps=connection.prepareStatement(sql);

        ResultSet rs=ps.executeQuery();
        while(rs.next())
        {   Vaccine vaccineslot=new Vaccine();
            vaccineslot.setVaccine_name(rs.getString(1));
            vaccineslot.setLocation(rs.getString(2));
            vaccineslot.setQuantity(rs.getInt(3));            
            slots.add(vaccineslot);   
        }
    }catch(Exception e){
        e.printStackTrace();
    }
        return slots;
	}

	@Override
	public Vaccine getVaccineDetails(String vaccine_name) {
        // TODO Auto-generated method stub
        Vaccine vaccine=new Vaccine();
        String sql="Select * from vaccinecentredata where vaccine_name=?";
                Connection connection=null;
        try{
            connection=Connectivity.getMySqlConnecion();
        PreparedStatement ps=connection.prepareStatement(sql);
        ps.setString(1,vaccine_name);

        ResultSet rs=ps.executeQuery();
        if(rs.next())
        {   vaccine.setVaccine_name(rs.getString(1));
            vaccine.setLocation(rs.getString(2));
            vaccine.setQuantity(rs.getInt(3));
        }
    }catch(Exception e){
        e.printStackTrace();
    }
        return vaccine;
	}

}
